/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Questao1;


/**
 *
 * @author rwsouza
 */
public class Pessoa {
   private double altura;
   private double peso;
   private String nome;
   
   public double calcularImc(){
     return peso / Math.pow(altura,2);
   } 
   
   public double getAltura() {
       return altura; 
   }
   
   public void setAltura(double altura){
      this.altura = altura; 
   }
   
   public double getPeso(){
       return peso;
   }
   
   public void setPeso(double peso){
       this.peso = peso;
   }
   
   public String getNome(){
       return nome; 
   }
   
   public void setNome(String nome){
     this.nome = nome;     
   }
    
}
