
//Comentário de linha

/*
Comentário de bloco
 ---linha 1
 ---linha 2
*/

/**
 * Comentário Javadoc
 */


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Questao2;

/**
 * Essa Classe representa uma Conta Bancária
 * @author Robson Walter de Souza
 * @author fulano
 */
public class ContaBancaria {
  /**
   * 
   */
  private String numero;
  private String titular;
  private double saldo;
  
  /**
   * Metodo responsável por retornar o número da conta
   * @return Número da Conta 
   */
  public String getNumero(){
    return numero;  
  }
  
  public void setNumero(String numero){
     this.numero = numero; 
  }
  
  public String getTitular(){
      return titular;
  }
  
  public void setTitular(String titular){
      this.titular = titular;
  }
  
  public double getSaldo(){
      return saldo;
  }
  
  public void depositar(double valor){
    if (valor < 0){
       throw new IllegalArgumentException("Valor não pode ser negativo");
    }
    
    saldo += valor;
      //saldo = saldo + valor;
  }
  
  public void sacar(double valor){
    if (valor < 0){
       throw new IllegalArgumentException("Valor não pode ser negativo!");
    } 
    
    if ((saldo - valor) < 0){
       throw new IllegalArgumentException("Saldo insuficiente para saque!");
    }    
    
      
    saldo -= valor;  
  }
  
  /**
   * Método responsável por transferir valor entre duas contas bancárias
   *   <ul>
   *     <li> Teste1<li>
   *     <li> Teste2</li>
   *   </ul>
   * @param contaDestino Conta destino para transferência
   * @param valor Valor a ser transferido
   */
  public void transferir(ContaBancaria contaDestino, double valor){
    sacar(valor);
    contaDestino.depositar(valor);
  }
  
  
}
