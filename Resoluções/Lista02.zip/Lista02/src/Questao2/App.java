


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Questao2;

import java.util.Scanner;

/**
 *
 * @author rwsouza
 */

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ContaBancaria conta1 = new ContaBancaria();
        ContaBancaria conta2 = new ContaBancaria();
        
       //Solicitando dados da primeira conta 
        System.out.println("Informe o número da Primeira Conta:");
        conta1.setNumero(sc.nextLine());        
        System.out.println("Informe o titular da conta "+conta1.getNumero()+":");
        conta1.setTitular(sc.nextLine());
        
        //Solicitando dados da segunda conta
        System.out.println("Informe o número da Segunda Conta:");
        conta2.setNumero(sc.nextLine());        
        System.out.println("Informe o titular da conta "+conta2.getNumero()+":");
        conta2.setTitular(sc.nextLine());
        
        /*a. Realize depósitos na primeira conta nos
          valores de R$ 1.000,00 e R$ 700,00*/
        
        conta1.depositar(1000);
        conta1.depositar(700);
        
        /*b. Realize depósitos na segunda conta nos valores de R$ 5.000,00*/
        
        conta2.depositar(5000);
        
        /*c. Faça um saque na 2ª conta no valor de R$ 3.000,00.*/
        conta2.sacar(3000);

        /*d. Transfira R$ 1.800,00 da 2ª conta para a 1ª conta.*/
        conta2.transferir(conta1, 1800);
        
        /*e. Exiba o titular de cada uma conta com o respectivo saldo da conta.*/
        
        System.out.println(" ********* RELATÓRIO **********");
        System.out.println(" Titular: "+conta1.getTitular()+ 
                           " Saldo R$ "+conta1.getSaldo());
        
        System.out.println(" Titular: "+conta2.getTitular()+ 
                           " Saldo R$ "+conta2.getSaldo());
        
        
        
        
        
        
        
    }
  
}
