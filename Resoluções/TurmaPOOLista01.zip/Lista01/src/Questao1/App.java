/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Questao1;

import java.text.DecimalFormat;

/**
 *
 * @author rwsouza
 */
public class App {
    public static void main(String[] args) {
        /*No método main() da classe App utilize a classe Pessoa
          para calcular o IMC de uma pessoa que tem 1,75 m de altura
         e 78 Kg. O programa deverá apresentar o IMC calculado na tela.*/
        
        Pessoa pessoa = new Pessoa();
        
        pessoa.altura = 1.75;
        pessoa.peso = 78;
        
        double imc = pessoa.calcularImc();
        DecimalFormat df = new DecimalFormat("0.00");
        
        System.out.println("IMC é: "+df.format(imc));
        
        //System.out.println("IMC é: "+pessoa.calcularImc());
        
        

    }
}
