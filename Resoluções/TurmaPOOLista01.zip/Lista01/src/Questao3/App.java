/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Questao3;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author rwsouza
 */
public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Pessoa pessoa = new Pessoa();
        DecimalFormat df = new DecimalFormat("0.00");
        for (int i = 0; i <= 2;i++){
            System.out.println(" ******* "+(i+1)+" ª Pessoa *******");
            System.out.println("Informe a Altura: ");
            pessoa.altura = sc.nextDouble();

            System.out.println("Informe o Peso: ");
            pessoa.peso = sc.nextDouble();
            
            System.out.println("IMC: "+df.format(pessoa.calcularImc()));
            System.out.println(" **********************************");
        }
        
        
        
         
        
        
    }
}
